#include <stdio.h>

int main() {
    int r, c;
    if (scanf("%d %d", &r, &c) != 2) {
        return 0;
    }
    long long mat[100][100];
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            scanf("%lld", &mat[i][j]);
        }
    }
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            long long val = mat[i][j];
            int isRowMin = 1;
            for (int k = 0; k < c; k++) {
                if (mat[i][k] < val) {
                    isRowMin = 0;
                    break;
                }
            }
            if (!isRowMin) continue;

            int isColMax = 1;
            for (int k = 0; k < r; k++) {
                if (mat[k][j] > val) {
                    isColMax = 0;
                    break;
                }
            }
            if (isColMax) {
                printf("%d %d %lld\n", i, j, val);
                return 0;
            }
        }
    }
    printf("None\n");
    return 0;
}
