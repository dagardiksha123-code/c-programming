#include <stdio.h>

int main() {
    int r, c;
    if (scanf("%d %d", &r, &c) != 2) {
        return 0;
    }
    long long mat[100][100];
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            scanf("%lld", &mat[i][j]);
        }
    }
    for (int i = 0; i < r; i++) {
        long long rSum = 0;
        for (int j = 0; j < c; j++) {
            rSum += mat[i][j];
        }
        printf("%lld%s", rSum, (i == r - 1) ? "" : " ");
    }
    printf("\n");
    for (int j = 0; j < c; j++) {
        long long cSum = 0;
        for (int i = 0; i < r; i++) {
            cSum += mat[i][j];
        }
        printf("%lld%s", cSum, (j == c - 1) ? "" : " ");
    }
    printf("\n");
    return 0;
}
