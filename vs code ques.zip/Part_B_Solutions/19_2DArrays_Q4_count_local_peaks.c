#include <stdio.h>

int main() {
    int r, c;
    if (scanf("%d %d", &r, &c) != 2) {
        return 0;
    }
    long long mat[100][100];
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            scanf("%lld", &mat[i][j]);
        }
    }
    int peaks = 0;
    int dr[4] = {-1, 1, 0, 0};
    int dc[4] = {0, 0, -1, 1};
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            int isPeak = 1;
            for (int d = 0; d < 4; d++) {
                int nr = i + dr[d];
                int nc = j + dc[d];
                if (nr >= 0 && nr < r && nc >= 0 && nc < c) {
                    if (mat[i][j] <= mat[nr][nc]) {
                        isPeak = 0;
                        break;
                    }
                }
            }
            if (isPeak) {
                peaks++;
            }
        }
    }
    printf("%d\n", peaks);
    return 0;
}
