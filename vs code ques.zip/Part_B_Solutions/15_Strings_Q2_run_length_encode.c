#include <stdio.h>
#include <string.h>

int main() {
    char s[1005];
    if (scanf("%1000s", s) != 1) {
        return 0;
    }
    int len = (int)strlen(s);
    if (len == 0) {
        printf("\n");
        return 0;
    }
    int count = 1;
    for (int i = 1; i <= len; i++) {
        if (i < len && s[i] == s[i - 1]) {
            count++;
        } else {
            printf("%c%d", s[i - 1], count);
            count = 1;
        }
    }
    printf("\n");
    return 0;
}
