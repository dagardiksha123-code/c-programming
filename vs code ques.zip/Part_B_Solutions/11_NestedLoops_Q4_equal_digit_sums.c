#include <stdio.h>

int digitSum(long long num) {
    if (num < 0) num = -num;
    int sum = 0;
    while (num > 0) {
        sum += num % 10;
        num /= 10;
    }
    return sum;
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) {
        return 0;
    }
    long long arr[1000];
    int sums[1000];
    for (int i = 0; i < n; i++) {
        scanf("%lld", &arr[i]);
        sums[i] = digitSum(arr[i]);
    }
    long long count = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (sums[i] == sums[j]) {
                count++;
            }
        }
    }
    printf("%lld\n", count);
    return 0;
}
